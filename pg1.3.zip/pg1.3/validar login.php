<?php

session_start();
include 'db.php';


$correo=$_POST['email'];
$contras=$_POST['contra'];


$validar_inic = mysqli_query($conexion,"SELECT * FROM usuarios WHERE email='$correo' and contrasena='$contras'");

if(mysqli_num_rows($validar_inic) > 0 ){
    $_SESSION['usuario']=$correo ;
    echo'
    <script>
        window.location ="PPagPrincipal.html";
        </script>';
    exit;

}
else{
    echo '
    <script>
        alert("Usuario NO EXISTENTE vuelva a intentarlo o registrese");
        window.location ="formulario cambalaches.php";
        </script>';
    exit;

}
?>