<?php
// ...
session_start();

// Verificar si el usuario no ha iniciado sesión
if (!isset($_SESSION['email'])) {
    header("Location: login.php");
    exit();
}

// Obtener el email del usuario para mostrarlo en la página de administrador
$email = $_SESSION['email'];

// Conexión a la base de datos (reemplaza los valores con los de tu configuración)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "cambalaches";

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die("Error en la conexión: " . $conn->connect_error);
}
// Obtener registros de la tabla 'roles'
$query = "SELECT * FROM roles";
$result = mysqli_query($conn, $query);

// Agregar un nuevo rol
if (isset($_POST['add_role'])) {
    $desc_rol = $_POST['desc_rol'];
    $query = "INSERT INTO roles (desc_rol) VALUES ('$desc_rol')";
    mysqli_query($conn, $query);
    header("Location: admin.php");
    exit();
}

// Actualizar un rol existente
if (isset($_POST['update_role'])) {
    $cod_rol = $_POST['cod_rol'];
    $desc_rol = $_POST['desc_rol'];
    $query = "UPDATE roles SET desc_rol='$desc_rol' WHERE cod_rol='$cod_rol'";
    mysqli_query($conn, $query);
    header("Location: admin.php");
    exit();
}

// Eliminar un rol
if (isset($_GET['delete_role'])) {
    $cod_rol = $_GET['delete_role'];
    $query = "DELETE FROM roles WHERE cod_rol='$cod_rol'";
    mysqli_query($conn, $query);
    header("Location: admin.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Página de Administrador</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }
        th, td {
            border: 1px solid black;
            padding: 8px;
            text-align: left;
        }
    </style>
</head>
<body>
    <h2>Bienvenido, <?php echo $email; ?></h2>
    <p>Contenido exclusivo para usuarios administradores.</p>
    <a href="logout.php">Cerrar sesión</a>

    <h3>Roles</h3>

    <!-- Mostrar registros de la tabla 'roles' en una tabla HTML -->
    <table>
        <tr>
            <th>Código de Rol</th>
            <th>Descripción</th>
            <th>Acciones</th>
        </tr>
        <?php while ($row = mysqli_fetch_assoc($result)) { ?>
            <tr>
                <td><?php echo $row['cod_rol']; ?></td>
                <td><?php echo $row['desc_rol']; ?></td>
                <td>
                    <!-- Botones para editar y eliminar un rol -->
                    <a href="admin.php?edit_role=<?php echo $row['cod_rol']; ?>">Editar</a>
                    <a href="admin.php?delete_role=<?php echo $row['cod_rol']; ?>" onclick="return confirm('¿Estás seguro de eliminar este rol?')">Eliminar</a>
                </td>
            </tr>
        <?php } ?>
    </table>

    <!-- Formulario para agregar o actualizar un rol -->
    <h4>Agregar/Actualizar Rol</h4>
    <form method="POST" action="admin.php">
        <input type="hidden" name="cod_rol" value="<?php echo isset($_GET['edit_role']) ? $_GET['edit_role'] : ''; ?>">
        <label>Descripción:</label>
        <input type="text" name="desc_rol" value="<?php echo isset($_GET['edit_role']) ? $edit_desc_rol : ''; ?>">
        <?php if (isset($_GET['edit_role'])) { ?>
            <button type="submit" name="update_role">Actualizar</button>
        <?php } else { ?>
            <button type="submit" name="add_role">Agregar</button>
        <?php } ?>
    </form>
    <a href="admin.php">Volver al panel de administración</a>
</body>
</html>
