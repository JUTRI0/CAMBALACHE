<?php
session_start();

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION['email'])) {
    header("Location: login.php");
    exit();
}

// Obtener el email del usuario
$email = $_SESSION['email'];

// Obtener los productos de la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Cambalaches";

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Consulta para obtener los productos
$sql = "SELECT * FROM productos";
$result = $conn->query($sql);

// Crear un array para almacenar los productos
$productos = array();

// Verificar si se obtuvieron resultados
if ($result->num_rows > 0) {
    // Recorrer los resultados y almacenar los productos en el array
    while ($row = $result->fetch_assoc()) {
        $productos[] = $row;
    }
}

// Cerrar la conexión
$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Lista de Productos</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        .product-row {
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2 class="mt-4">Lista de Productos</h2>
        <h4 class="mt-4">Bienvenido, <?php echo $email; ?></h4>

        <div class="row mt-4">
            <?php foreach ($productos as $producto): ?>
                <div class="col-md-4 product-row">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo isset($producto['nombre']) ? $producto['nombre'] : ''; ?></h5>
                            <p class="card-text"><?php echo isset($producto['descripcion']) ? $producto['descripcion'] : ''; ?></p>
                            <p class="card-text">Precio: <?php echo isset($producto['precio']) ? $producto['precio'] : ''; ?></p>
                            <form action="Agregar_productos.php" method="post">
                                <input type="hidden" name="cod_producto" value="<?php echo isset($producto['codigo']) ? $producto['codigo'] : ''; ?>">
                                <input type="hidden" name="desc_producto" value="<?php echo isset($producto['nombre']) ? $producto['nombre'] : ''; ?>">
                                <input type="number" name="cantidad_prod" value="1" min="1" class="form-control" required>
                                <input type="hidden" name="valor_prod_cant" value="<?php echo isset($producto['precio']) ? $producto['precio'] : ''; ?>">
                                <input type="submit" class="btn btn-primary" value="Agregar al carrito">
                            </form>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <div class="mt-4">
            <a href="Carrito.php" class="btn btn-info">Ver carrito</a>
            <a href="logout.php" class="btn btn-danger">Cerrar sesión</a>
        </div>
    </div>

    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
