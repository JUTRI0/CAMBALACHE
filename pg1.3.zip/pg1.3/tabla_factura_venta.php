<?php
session_start();

// Verificar si el usuario no ha iniciado sesión
if (!isset($_SESSION['email'])) {
    header("Location: login.php");
    exit();
}

// Obtener el email del usuario para mostrarlo en la página de administrador
$email = $_SESSION['email'];

// Conexión a la base de datos
$host = 'localhost';
$db = 'cambalaches';
$user = 'root';
$password = '';

try {
    $conn = new PDO("mysql:host=$host;dbname=$db", $user, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    echo "Error de conexión: " . $e->getMessage();
}

// Función para obtener todos los registros de factura_venta
function obtenerFacturasVenta($conn) {
    $query = "SELECT * FROM factura_venta";
    $stmt = $conn->prepare($query);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Función para agregar una nueva factura_venta
function agregarFacturaVenta($conn, $n_factura_vent, $comprador_tdoc, $comprador_id, $vendedor_tdoc_v, $vendedor_id_v) {
    $query = "INSERT INTO factura_venta (n_factura_vent, comprador_tdoc, comprador_id, vendedor_tdoc_v, vendedor_id_v)
              VALUES (:n_factura_vent, :comprador_tdoc, :comprador_id, :vendedor_tdoc_v, :vendedor_id_v)";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':n_factura_vent', $n_factura_vent);
    $stmt->bindParam(':comprador_tdoc', $comprador_tdoc);
    $stmt->bindParam(':comprador_id', $comprador_id);
    $stmt->bindParam(':vendedor_tdoc_v', $vendedor_tdoc_v);
    $stmt->bindParam(':vendedor_id_v', $vendedor_id_v);
    $stmt->execute();
}

// Función para eliminar una factura_venta
function eliminarFacturaVenta($conn, $n_factura_vent) {
    $query = "DELETE FROM factura_venta WHERE n_factura_vent = :n_factura_vent";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':n_factura_vent', $n_factura_vent);
    $stmt->execute();
}

// Función para actualizar una factura_venta
function actualizarFacturaVenta($conn, $n_factura_vent, $comprador_tdoc, $comprador_id, $vendedor_tdoc_v, $vendedor_id_v) {
    $query = "UPDATE factura_venta
              SET comprador_tdoc = :comprador_tdoc, comprador_id = :comprador_id,
                  vendedor_tdoc_v = :vendedor_tdoc_v, vendedor_id_v = :vendedor_id_v
              WHERE n_factura_vent = :n_factura_vent";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':comprador_tdoc', $comprador_tdoc);
    $stmt->bindParam(':comprador_id', $comprador_id);
    $stmt->bindParam(':vendedor_tdoc_v', $vendedor_tdoc_v);
    $stmt->bindParam(':vendedor_id_v', $vendedor_id_v);
    $stmt->bindParam(':n_factura_vent', $n_factura_vent);
    $stmt->execute();
}

// Obtener todas las facturas_venta
$facturas_venta = obtenerFacturasVenta($conn);

// Procesar el formulario de agregar factura_venta
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['agregar'])) {
    $n_factura_vent = $_POST['n_factura_vent'];
    $comprador_tdoc = $_POST['comprador_tdoc'];
    $comprador_id = $_POST['comprador_id'];
    $vendedor_tdoc_v = $_POST['vendedor_tdoc_v'];
    $vendedor_id_v = $_POST['vendedor_id_v'];
    agregarFacturaVenta($conn, $n_factura_vent, $comprador_tdoc, $comprador_id, $vendedor_tdoc_v, $vendedor_id_v);
    header("Location: admin.php");
    exit();
}

// Procesar el formulario de eliminar factura_venta
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['eliminar'])) {
    $n_factura_vent = $_POST['eliminar'];
    eliminarFacturaVenta($conn, $n_factura_vent);
    header("Location: admin.php");
    exit();
}

// Procesar el formulario de actualizar factura_venta
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['actualizar'])) {
    $n_factura_vent = $_POST['n_factura_vent'];
    $comprador_tdoc = $_POST['comprador_tdoc'];
    $comprador_id = $_POST['comprador_id'];
    $vendedor_tdoc_v = $_POST['vendedor_tdoc_v'];
    $vendedor_id_v = $_POST['vendedor_id_v'];
    actualizarFacturaVenta($conn, $n_factura_vent, $comprador_tdoc, $comprador_id, $vendedor_tdoc_v, $vendedor_id_v);
    header("Location: admin.php");
    exit();
}

?>

<!DOCTYPE html>
<html>
<head>
    <title>CRUD - Tabla factura_venta</title>
</head>
<body>
    <h2>Bienvenido, <?php echo $email; ?></h2>
    <h3>Tabla factura_venta</h3>

    <!-- Mostrar registros existentes -->
    <?php if (count($facturas_venta) > 0): ?>
        <table>
            <tr>
                <th>Número Factura</th>
                <th>Comprador Tipo Documento</th>
                <th>Comprador ID</th>
                <th>Vendedor Tipo Documento</th>
                <th>Vendedor ID</th>
                <th>Acciones</th>
            </tr>
            <?php foreach ($facturas_venta as $factura_venta): ?>
                <tr>
                    <td><?php echo $factura_venta['n_factura_vent']; ?></td>
                    <td><?php echo $factura_venta['comprador_tdoc']; ?></td>
                    <td><?php echo $factura_venta['comprador_id']; ?></td>
                    <td><?php echo $factura_venta['vendedor_tdoc_v']; ?></td>
                    <td><?php echo $factura_venta['vendedor_id_v']; ?></td>
                    <td>
                        <form method="POST" style="display:inline;">
                            <input type="hidden" name="eliminar" value="<?php echo $factura_venta['n_factura_vent']; ?>">
                            <button type="submit">Eliminar</button>
                        </form>
                        <button onclick="mostrarFormularioActualizar('<?php echo $factura_venta['n_factura_vent']; ?>',
                                                                  '<?php echo $factura_venta['comprador_tdoc']; ?>',
                                                                  '<?php echo $factura_venta['comprador_id']; ?>',
                                                                  '<?php echo $factura_venta['vendedor_tdoc_v']; ?>',
                                                                  '<?php echo $factura_venta['vendedor_id_v']; ?>')">Actualizar</button>
                    </td>
                </tr>
            <?php endforeach; ?>
        </table>
    <?php else: ?>
        <p>No hay registros.</p>
    <?php endif; ?>

    <!-- Formulario para agregar o actualizar factura_venta -->
    <h3><?php echo isset($_POST['actualizar']) ? 'Actualizar Factura Venta' : 'Agregar Factura Venta'; ?></h3>
    <form method="POST">
        <label for="n_factura_vent">Número Factura:</label>
        <input type="text" name="n_factura_vent" id="n_factura_vent" required>
        <br>
        <label for="comprador_tdoc">Comprador Tipo Documento:</label>
        <input type="text" name="comprador_tdoc" id="comprador_tdoc" required>
        <br>
        <label for="comprador_id">Comprador ID:</label>
        <input type="text" name="comprador_id" id="comprador_id" required>
        <br>
        <label for="vendedor_tdoc_v">Vendedor Tipo Documento:</label>
        <input type="text" name="vendedor_tdoc_v" id="vendedor_tdoc_v" required>
        <br>
        <label for="vendedor_id_v">Vendedor ID:</label>
        <input type="text" name="vendedor_id_v" id="vendedor_id_v" required>
        <br>
        <button type="submit" name="agregar">Agregar</button>
        <button type="submit" name="actualizar" id="btn-actualizar" style="display: none;">Actualizar</button>
    </form>
    <a href="admin.php">Volver al panel de administración</a>

    <!-- JavaScript para mostrar formulario de actualización -->
    <script>
        function mostrarFormularioActualizar(n_factura_vent, comprador_tdoc, comprador_id, vendedor_tdoc_v, vendedor_id_v) {
            document.getElementById('n_factura_vent').value = n_factura_vent;
            document.getElementById('comprador_tdoc').value = comprador_tdoc;
            document.getElementById('comprador_id').value = comprador_id;
            document.getElementById('vendedor_tdoc_v').value = vendedor_tdoc_v;
            document.getElementById('vendedor_id_v').value = vendedor_id_v;
            document.getElementById('btn-actualizar').style.display = 'inline';
        }
    </script>
</body>
</html>
