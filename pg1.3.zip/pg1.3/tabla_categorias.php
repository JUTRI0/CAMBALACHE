<?php
// Configuración de la conexión a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "cambalaches";

// Crear la conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar si hay errores en la conexión
if ($conn->connect_error) {
    die("Error en la conexión a la base de datos: " . $conn->connect_error);
}

// Función para obtener todas las categorías
function obtenerCategorias($conn) {
    $sql = "SELECT * FROM categorias";
    $result = $conn->query($sql);
    $categorias = array();

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $categorias[] = $row;
        }
    }

    return $categorias;
}

// Función para insertar una nueva categoría
function insertarCategoria($conn, $cod_categoria, $nom_categoria, $estado_tprod) {
    $sql = "INSERT INTO categorias (cod_categoria, nom_categoria, estado_tprod) VALUES ('$cod_categoria', '$nom_categoria', $estado_tprod)";
    
    if ($conn->query($sql) === TRUE) {
        return true;
    } else {
        echo "Error al insertar la categoría: " . $conn->error;
        return false;
    }
}

// Función para actualizar una categoría existente
function actualizarCategoria($conn, $cod_categoria, $nom_categoria, $estado_tprod) {
    $sql = "UPDATE categorias SET nom_categoria='$nom_categoria', estado_tprod=$estado_tprod WHERE cod_categoria='$cod_categoria'";
    
    if ($conn->query($sql) === TRUE) {
        return true;
    } else {
        echo "Error al actualizar la categoría: " . $conn->error;
        return false;
    }
}

// Función para eliminar una categoría
function eliminarCategoria($conn, $cod_categoria) {
    $sql = "DELETE FROM categorias WHERE cod_categoria='$cod_categoria'";
    
    if ($conn->query($sql) === TRUE) {
        return true;
    } else {
        echo "Error al eliminar la categoría: " . $conn->error;
        return false;
    }
}

// Obtener todas las categorías
$categorias = obtenerCategorias($conn);

// Procesar el formulario de inserción o actualización
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['insertar'])) {
        $cod_categoria = $_POST['cod_categoria'];
        $nom_categoria = $_POST['nom_categoria'];
        $estado_tprod = isset($_POST['estado_tprod']) ? 1 : 0;

        insertarCategoria($conn, $cod_categoria, $nom_categoria, $estado_tprod);
    } elseif (isset($_POST['actualizar'])) {
        $cod_categoria = $_POST['cod_categoria'];
        $nom_categoria = $_POST['nom_categoria'];
        $estado_tprod = isset($_POST['estado_tprod']) ? 1 : 0;

        actualizarCategoria($conn, $cod_categoria, $nom_categoria, $estado_tprod);
    }
}

// Procesar la eliminación de una categoría
if (isset($_GET['eliminar'])) {
    $cod_categoria = $_GET['eliminar'];

    eliminarCategoria($conn, $cod_categoria);
}

// Cerrar la conexión a la base de datos
$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>CRUD Categorías</title>
    <style>
        table {
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid black;
            padding: 5px;
        }
    </style>
</head>
<body>
    <h2>CRUD Categorías</h2>

    <h3>Lista de Categorías</h3>
    <table>
        <tr>
            <th>Código</th>
            <th>Nombre</th>
            <th>Estado</th>
            <th>Acciones</th>
        </tr>
        <?php foreach ($categorias as $categoria) { ?>
            <tr>
                <td><?php echo $categoria['cod_categoria']; ?></td>
                <td><?php echo $categoria['nom_categoria']; ?></td>
                <td><?php echo $categoria['estado_tprod']; ?></td>
                <td>
                    <a href="?eliminar=<?php echo $categoria['cod_categoria']; ?>">Eliminar</a>
                    <button onclick="editarCategoria('<?php echo $categoria['cod_categoria']; ?>', '<?php echo $categoria['nom_categoria']; ?>', <?php echo $categoria['estado_tprod']; ?>)">Editar</button>
                </td>
            </tr>
        <?php } ?>
    </table>

    <h3>Agregar Categoría</h3>
    <form method="POST">
        <label>Código:</label>
        <input type="text" name="cod_categoria" required><br><br>
        <label>Nombre:</label>
        <input type="text" name="nom_categoria" required><br><br>
        <label>Estado:</label>
        <input type="checkbox" name="estado_tprod"><br><br>
        <input type="submit" name="insertar" value="Insertar">
    </form>

    <h3>Actualizar Categoría</h3>
    <form id="editarForm" method="POST" style="display: none;">
        <input type="hidden" name="cod_categoria" id="cod_categoria">
        <label>Nombre:</label>
        <input type="text" name="nom_categoria" id="nom_categoria" required><br><br>
        <label>Estado:</label>
        <input type="checkbox" name="estado_tprod" id="estado_tprod"><br><br>
        <input type="submit" name="actualizar" value="Actualizar">
    </form>
    <a href="admin.php">Volver al panel de administración</a>

    <script>
        function editarCategoria(cod_categoria, nom_categoria, estado_tprod) {
            document.getElementById('cod_categoria').value = cod_categoria;
            document.getElementById('nom_categoria').value = nom_categoria;
            document.getElementById('estado_tprod').checked = estado_tprod === 1;
            document.getElementById('editarForm').style.display = 'block';
        }
    </script>
</body>
</html>
