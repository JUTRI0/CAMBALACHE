<?php
// Conexión a la base de datos (reemplaza los valores con los de tu configuración)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "cambalaches";

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die("Error en la conexión: " . $conn->connect_error);
}

// Función para obtener todos los productos de la base de datos
function obtenerProductos($conn)
{
    $sql = "SELECT * FROM productos";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        return $result->fetch_all(MYSQLI_ASSOC);
    } else {
        return array();
    }
}

// Función para agregar un nuevo producto
function agregarProducto($conn, $cod_producto, $desc_producto, $valor_prod, $fk_tipo_prod)
{
    $sql = "INSERT INTO productos (cod_producto, desc_producto, valor_prod, fk_tipo_prod)
            VALUES ('$cod_producto', '$desc_producto', $valor_prod, '$fk_tipo_prod')";

    if ($conn->query($sql) === TRUE) {
        return true;
    } else {
        return false;
    }
}

// Función para eliminar un producto
function eliminarProducto($conn, $cod_producto)
{
    $sql = "DELETE FROM productos WHERE cod_producto = '$cod_producto'";

    if ($conn->query($sql) === TRUE) {
        return true;
    } else {
        return false;
    }
}

// Función para actualizar un producto
function actualizarProducto($conn, $cod_producto, $desc_producto, $valor_prod, $fk_tipo_prod)
{
    $sql = "UPDATE productos SET desc_producto = '$desc_producto', valor_prod = $valor_prod, fk_tipo_prod = '$fk_tipo_prod'
            WHERE cod_producto = '$cod_producto'";

    if ($conn->query($sql) === TRUE) {
        return true;
    } else {
        return false;
    }
}

// Procesar las acciones de agregar, eliminar y actualizar
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["agregar"])) {
        $cod_producto = $_POST["cod_producto"];
        $desc_producto = $_POST["desc_producto"];
        $valor_prod = $_POST["valor_prod"];
        $fk_tipo_prod = $_POST["fk_tipo_prod"];

        agregarProducto($conn, $cod_producto, $desc_producto, $valor_prod, $fk_tipo_prod);
    } elseif (isset($_POST["eliminar"])) {
        $cod_producto = $_POST["eliminar"];

        eliminarProducto($conn, $cod_producto);
    } elseif (isset($_POST["actualizar"])) {
        $cod_producto = $_POST["cod_producto"];
        $desc_producto = $_POST["desc_producto"];
        $valor_prod = $_POST["valor_prod"];
        $fk_tipo_prod = $_POST["fk_tipo_prod"];

        actualizarProducto($conn, $cod_producto, $desc_producto, $valor_prod, $fk_tipo_prod);
    }
}

// Obtener todos los productos de la base de datos
$productos = obtenerProductos($conn);

// Cerrar la conexión
$conn->close();
?>

<!DOCTYPE html>
<html>

<head>
    <title>Administración de Productos</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #fbc2eb;
            background: -webkit-linear-gradient(to right, rgba(251, 194, 235, 1), rgba(166, 193, 238, 1));
            background: linear-gradient(to right, rgba(251, 194, 235, 1), rgba(166, 193, 238, 1));
            height: 100vh;
            margin: 0;
            padding: 20px;
        }

        h3 {
            color: #333;
        }

        h4 {
            color: #555;
            margin-bottom: 10px;
        }

        form {
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th,
        td {
            padding: 10px;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #F2F2F2;
            text-align: left;
            color: #333;
        }

        td {
            background-color: #FFF;
            color: #555;
        }

        input[type="text"],
        input[type="number"] {
            padding: 5px;
            border: 1px solid #ddd;
            border-radius: 3px;
        }

        input[type="submit"] {
            padding: 5px 10px;
            background-color: #333;
            color: #FFF;
            border: none;
            cursor: pointer;
        }

        a {
            color: #333;
            text-decoration: none;
            margin-top: 10px;
            display: inline-block;
        }
    </style>
</head>

<body>
    <h3>Administración de Productos</h3>

    <!-- Formulario para agregar un nuevo producto -->
    <h4>Agregar Producto</h4>
    <form method="POST" action="">
        Código: <input type="text" name="cod_producto" required><br>
        Descripción: <input type="text" name="desc_producto" required><br>
        Valor: <input type="number" name="valor_prod" required><br>
        Tipo: <input type="text" name="fk_tipo_prod" required><br>
        <input type="submit" name="agregar" value="Agregar">
    </form>

    <!-- Mostrar la lista de productos -->
    <h4>Lista de Productos</h4>
    <table>
        <tr>
            <th>Código</th>
            <th>Descripción</th>
            <th>Valor</th>
            <th>Tipo</th>
            <th>Acciones</th>
        </tr>
        <?php foreach ($productos as $producto) { ?>
            <tr>
                <td><?php echo $producto['cod_producto']; ?></td>
                <td><?php echo $producto['desc_producto']; ?></td>
                <td><?php echo $producto['valor_prod']; ?></td>
                <td><?php echo $producto['fk_tipo_prod']; ?></td>
                <td>
                    <!-- Formulario para eliminar un producto -->
                    <form method="POST" action="">
                        <input type="hidden" name="eliminar" value="<?php echo $producto['cod_producto']; ?>">
                        <input type="submit" value="Eliminar">
                    </form>

                    <!-- Formulario para actualizar un producto -->
                    <form method="POST" action="">
                        <input type="hidden" name="cod_producto" value="<?php echo $producto['cod_producto']; ?>">
                        Descripción: <input type="text" name="desc_producto" value="<?php echo $producto['desc_producto']; ?>" required>
                        Valor: <input type="number" name="valor_prod" value="<?php echo $producto['valor_prod']; ?>" required>
                        Tipo: <input type="text" name="fk_tipo_prod" value="<?php echo $producto['fk_tipo_prod']; ?>" required>
                        <input type="submit" name="actualizar" value="Actualizar">
                    </form>
                </td>
            </tr>
        <?php } ?>
    </table>

    <a href="Tienda.html">Volver a la tienda</a>
    <br>
</body>

</html>
