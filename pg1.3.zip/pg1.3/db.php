<?php
$conexion=mysqli_connect("localhost","root","","cambalaches");

?>