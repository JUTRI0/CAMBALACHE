<?Php
include 'db.php';
$tip_docum=$_POST['docu'];
$numdocu=$_POST['ndocu'];
$nom=$_POST['prnom'];
$seg_nom=$_POST['snom'];
$ape=$_POST['primapel'];
$seg_ape=$_POST['sapel'];
$corr=$_POST['correo'];
$telf=$_POST['tel'];
$contraseña= base64_encode($_POST['contra']);
$dirr=$_POST['direccion'];
//$contraseña=hash('sha512',$contraseña);

$registrar = "INSERT INTO usuarios (pk_fk_tdoc, id_usuario, nom_persona, nom2_persona, apell_persona, apell2_persona,direccion_persona,telefono,email,contrasena) 
values ('$tip_docum','$numdocu','$nom','$seg_nom','$ape','$seg_ape','$dirr','$telf','$corr','$contraseña')";



$verificar_Docum = mysqli_query($conexion,"SELECT * FROM usuarios WHERE id_usuario ='$numdocu'");

if(mysqli_num_rows($verificar_Docum) > 0 ){
    echo'
    <script>
        alert("EL Documento ya esta registrado, intenta con otro o inicia sesion");
        window.location ="formulario cambalaches.php";
        </script>
    ';
    exit();
}



$verificar_correo = mysqli_query($conexion,"SELECT * FROM usuarios WHERE email ='$corr'");

if(mysqli_num_rows($verificar_correo) > 0 ){
    echo'
    <script>
        alert("EL correo ya  esta registrado, intenta con otro");
        window.location ="formulario cambalaches.php";
        </script>
    ';
    exit();
}



$guardar =mysqli_query($conexion,$registrar);

if($guardar){
    echo '
    <script>
        alert("Usuario registrado exitosamente dale aceptar para continuar");
        window.location ="PagPrincipal.html";
        </script>';
}
else{
    echo '
    <script>
        alert("Usuario NO registrado vuelva a intentarlo");
        window.location ="formulario cambalaches.php";
        </script>';
}
mysqli_close($conexion);


?>