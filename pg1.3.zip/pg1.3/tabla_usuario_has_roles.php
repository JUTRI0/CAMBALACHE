<?php
session_start();

// Verificar si el usuario no ha iniciado sesión
if (!isset($_SESSION['email'])) {
    header("Location: login.php");
    exit();
}

// Obtener el email del usuario para mostrarlo en la página de administrador
$email = $_SESSION['email'];

// Configuración de la base de datos
$host = "localhost";
$username = "root";
$password = "";
$database = "cambalaches";

// Conexión a la base de datos
$conn = mysqli_connect($host, $username, $password, $database);

// Verificar si hay errores de conexión
if (mysqli_connect_errno()) {
    die("Error de conexión: " . mysqli_connect_error());
}

// Función para obtener todos los registros de la tabla usuario_has_roles
function obtenerRegistros()
{
    global $conn;

    $query = "SELECT * FROM usuario_has_roles";
    $result = mysqli_query($conn, $query);

    if (!$result) {
        die("Error al obtener registros: " . mysqli_error($conn));
    }

    $registros = array();

    while ($row = mysqli_fetch_assoc($result)) {
        $registros[] = $row;
    }

    return $registros;
}

// Función para agregar un nuevo registro a la tabla usuario_has_roles
function agregarRegistro($usuario_tdoc, $usuario_id, $usuario_rol)
{
    global $conn;

    $usuario_tdoc = mysqli_real_escape_string($conn, $usuario_tdoc);
    $usuario_id = mysqli_real_escape_string($conn, $usuario_id);
    $usuario_rol = mysqli_real_escape_string($conn, $usuario_rol);

    $query = "INSERT INTO usuario_has_roles (usuario_tdoc, usuario_id, usuario_rol) VALUES ('$usuario_tdoc', '$usuario_id', '$usuario_rol')";
    $result = mysqli_query($conn, $query);

    if (!$result) {
        die("Error al agregar el registro: " . mysqli_error($conn));
    }
}

// Función para borrar un registro de la tabla usuario_has_roles
function borrarRegistro($usuario_tdoc, $usuario_id, $usuario_rol)
{
    global $conn;

    $usuario_tdoc = mysqli_real_escape_string($conn, $usuario_tdoc);
    $usuario_id = mysqli_real_escape_string($conn, $usuario_id);
    $usuario_rol = mysqli_real_escape_string($conn, $usuario_rol);

    $query = "DELETE FROM usuario_has_roles WHERE usuario_tdoc = '$usuario_tdoc' AND usuario_id = '$usuario_id' AND usuario_rol = '$usuario_rol'";
    $result = mysqli_query($conn, $query);

    if (!$result) {
        die("Error al borrar el registro: " . mysqli_error($conn));
    }
}

// Función para actualizar un registro de la tabla usuario_has_roles
function actualizarRegistro($usuario_tdoc, $usuario_id, $usuario_rol, $nuevo_rol)
{
    global $conn;

    $usuario_tdoc = mysqli_real_escape_string($conn, $usuario_tdoc);
    $usuario_id = mysqli_real_escape_string($conn, $usuario_id);
    $usuario_rol = mysqli_real_escape_string($conn, $usuario_rol);
    $nuevo_rol = mysqli_real_escape_string($conn, $nuevo_rol);

    $query = "UPDATE usuario_has_roles SET usuario_rol = '$nuevo_rol' WHERE usuario_tdoc = '$usuario_tdoc' AND usuario_id = '$usuario_id' AND usuario_rol = '$usuario_rol'";
    $result = mysqli_query($conn, $query);

    if (!$result) {
        die("Error al actualizar el registro: " . mysqli_error($conn));
    }
}

// Procesar formularios
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Agregar registro
    if (isset($_POST['agregar'])) {
        $usuario_tdoc = $_POST['usuario_tdoc'];
        $usuario_id = $_POST['usuario_id'];
        $usuario_rol = $_POST['usuario_rol'];

        agregarRegistro($usuario_tdoc, $usuario_id, $usuario_rol);
    }
    // Borrar registro
    elseif (isset($_POST['borrar'])) {
        $usuario_tdoc = $_POST['usuario_tdoc'];
        $usuario_id = $_POST['usuario_id'];
        $usuario_rol = $_POST['usuario_rol'];

        borrarRegistro($usuario_tdoc, $usuario_id, $usuario_rol);
    }
    // Actualizar registro
    elseif (isset($_POST['actualizar'])) {
        $usuario_tdoc = $_POST['usuario_tdoc'];
        $usuario_id = $_POST['usuario_id'];
        $usuario_rol = $_POST['usuario_rol'];
        $nuevo_rol = $_POST['nuevo_rol'];

        actualizarRegistro($usuario_tdoc, $usuario_id, $usuario_rol, $nuevo_rol);
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Página de Administrador</title>
</head>
<body>
    <h2>Bienvenido, <?php echo $email; ?></h2>
    <p>Contenido exclusivo para usuarios administradores.</p>
    <h3>Tabla usuario_has_roles</h3>

    <!-- Formulario para agregar un nuevo registro -->
    <form method="POST" action="">
        <h4>Agregar registro</h4>
        <label for="usuario_tdoc">Tipo de documento:</label>
        <input type="text" name="usuario_tdoc" required>
        <label for="usuario_id">ID de usuario:</label>
        <input type="text" name="usuario_id" required>
        <label for="usuario_rol">Rol:</label>
        <input type="text" name="usuario_rol" required>
        <button type="submit" name="agregar">Agregar</button>
    </form>

    <!-- Formulario para actualizar un registro -->
    <form method="POST" action="">
        <h4>Actualizar registro</h4>
        <label for="usuario_tdoc">Tipo de documento:</label>
        <input type="text" name="usuario_tdoc" required>
        <label for="usuario_id">ID de usuario:</label>
        <input type="text" name="usuario_id" required>
        <label for="usuario_rol">Rol actual:</label>
        <input type="text" name="usuario_rol" required>
        <label for="nuevo_rol">Nuevo rol:</label>
        <input type="text" name="nuevo_rol" required>
        <button type="submit" name="actualizar">Actualizar</button>
    </form>

    <!-- Formulario para borrar un registro -->
    <form method="POST" action="">
        <h4>Borrar registro</h4>
        <label for="usuario_tdoc">Tipo de documento:</label>
        <input type="text" name="usuario_tdoc" required>
        <label for="usuario_id">ID de usuario:</label>
        <input type="text" name="usuario_id" required>
        <label for="usuario_rol">Rol:</label>
        <input type="text" name="usuario_rol" required>
        <button type="submit" name="borrar">Borrar</button>
    </form>
    

    <!-- Mostrar los registros actuales -->
    <h4>Registros actuales:</h4>
    <table>
        <tr>
            <th>Tipo de documento</th>
            <th>ID de usuario</th>
            <th>Rol</th>
        </tr>
        <?php
        $registros = obtenerRegistros();

        foreach ($registros as $registro) {
            echo "<tr>";
            echo "<td>" . $registro['usuario_tdoc'] . "</td>";
            echo "<td>" . $registro['usuario_id'] . "</td>";
            echo "<td>" . $registro['usuario_rol'] . "</td>";
            echo "</tr>";
        }
        ?>
    </table>
    <a href="admin.php">Volver al panel de administración</a>
</body>
</html>
