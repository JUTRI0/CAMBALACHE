<?php
session_start();

// Verificar si ya se ha iniciado sesión
if (isset($_SESSION['email'])) {
    header("Location: admin.php");
    exit();
}

// Verificar si se ha enviado el formulario de inicio de sesión
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Verificar las credenciales del usuario (aquí deberías realizar la verificación con tu lógica de autenticación)
    $email = $_POST['email'];
    $contrasena = $_POST['contrasena'];

    // Comprobar las combinaciones de correo electrónico y contraseña permitidas
    $allowedCredentials = array(
        "jul@a.com" => "12345",
        "n@correo.com" => "12345"
    );

    if (isset($allowedCredentials[$email]) && $allowedCredentials[$email] === $contrasena) {
        // Iniciar sesión y redirigir a admin.php
        $_SESSION['email'] = $email;
        header("Location: admin.php");
        exit();
    } else {
        // Las credenciales son inválidas, mostrar un mensaje de error
        $error = "Credenciales inválidas. Inténtalo de nuevo.";
    }
}

