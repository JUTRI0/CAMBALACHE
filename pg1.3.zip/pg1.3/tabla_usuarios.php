<?php
// Conexión a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "cambalaches";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

// Función para obtener todos los usuarios
function getUsuarios($conn)
{
    $sql = "SELECT * FROM usuarios";
    $result = $conn->query($sql);
    $usuarios = array();

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $usuarios[] = $row;
        }
    }

    return $usuarios;
}

// Función para agregar un nuevo usuario
function agregarUsuario($conn, $usuario)
{
    $sql = "INSERT INTO usuarios (pk_fk_tdoc, id_usuario, nom_persona, nom2_persona, apell_persona, apell2_persona, direccion_persona, telefono, email, contrasena)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssssssss", $usuario['pk_fk_tdoc'], $usuario['id_usuario'], $usuario['nom_persona'], $usuario['nom2_persona'], $usuario['apell_persona'], $usuario['apell2_persona'], $usuario['direccion_persona'], $usuario['telefono'], $usuario['email'], $usuario['contrasena']);

    return $stmt->execute();
}

// Función para actualizar un usuario existente
function actualizarUsuario($conn, $usuario)
{
    $sql = "UPDATE usuarios SET pk_fk_tdoc=?, id_usuario=?, nom_persona=?, nom2_persona=?, apell_persona=?, apell2_persona=?, direccion_persona=?, telefono=?, email=?, contrasena=?
            WHERE pk_fk_tdoc=? AND id_usuario=?";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssssssss", $usuario['pk_fk_tdoc'], $usuario['id_usuario'], $usuario['nom_persona'], $usuario['nom2_persona'], $usuario['apell_persona'], $usuario['apell2_persona'], $usuario['direccion_persona'], $usuario['telefono'], $usuario['email'], $usuario['contrasena'], $usuario['pk_fk_tdoc'], $usuario['id_usuario']);

    return $stmt->execute();
}

// Función para eliminar un usuario
function eliminarUsuario($conn, $pk_fk_tdoc, $id_usuario)
{
    $sql = "DELETE FROM usuarios WHERE pk_fk_tdoc=? AND id_usuario=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $pk_fk_tdoc, $id_usuario);

    return $stmt->execute();
}

// Procesar el formulario de agregar o actualizar usuario
if (isset($_POST['submit'])) {
    $usuario = array(
        'pk_fk_tdoc' => $_POST['pk_fk_tdoc'],
        'id_usuario' => $_POST['id_usuario'],
        'nom_persona' => $_POST['nom_persona'],
        'nom2_persona' => $_POST['nom2_persona'],
        'apell_persona' => $_POST['apell_persona'],
        'apell2_persona' => $_POST['apell2_persona'],
        'direccion_persona' => $_POST['direccion_persona'],
        'telefono' => $_POST['telefono'],
        'email' => $_POST['email'],
        'contrasena' => $_POST['contrasena']
    );

    if ($_POST['action'] === 'add') {
        agregarUsuario($conn, $usuario);
    } elseif ($_POST['action'] === 'edit') {
        actualizarUsuario($conn, $usuario);
    }
}

// Procesar la solicitud de eliminar usuario
if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['pk_fk_tdoc']) && isset($_GET['id_usuario'])) {
    eliminarUsuario($conn, $_GET['pk_fk_tdoc'], $_GET['id_usuario']);
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>CRUD de Usuarios</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }

        th, td {
            text-align: left;
            padding: 8px;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        .form-container {
            max-width: 400px;
            margin: 20px;
            padding: 16px;
            background-color: #f2f2f2;
        }

        .form-container input[type=text], .form-container input[type=password] {
            width: 100%;
            padding: 15px;
            margin: 5px 0 22px 0;
            border: none;
            background: #f1f1f1;
        }

        .form-container input[type=text]:focus, .form-container input[type=password]:focus {
            background-color: #ddd;
            outline: none;
        }

        .form-container .btn {
            background-color: #4CAF50;
            color: white;
            padding: 16px 20px;
            border: none;
            cursor: pointer;
            width: 100%;
            margin-bottom: 10px;
            opacity: 0.8;
        }

        .form-container .cancel {
            background-color: red;
        }

        .form-container .btn:hover, .open-button:hover {
            opacity: 1;
        }

        .open-button {
            background-color: #4CAF50;
            color: white;
            padding: 16px 20px;
            border: none;
            cursor: pointer;
            opacity: 0.8;
            position: fixed;
            bottom: 23px;
            right: 28px;
            width: 280px;
        }

        .open-button:hover {
            opacity: 1;
        }

        .crud-container {
            margin: 20px;
        }
    </style>
</head>
<body>

<br>
    <h2>Tabla de Usuarios</h2>

    <!-- Botón para abrir el formulario de agregar usuario -->
    <button class="open-button" onclick="openForm()">Agregar Usuario</button>

    <!-- Formulario para agregar o editar usuario -->
    <div class="form-popup" id="myForm">
        <form action="" method="POST" class="form-container">
            <h3 id="form-title">Agregar Usuario</h3>
            <input type="hidden" name="action" id="form-action" value="add">
            <input type="hidden" name="pk_fk_tdoc_edit" id="form-pk_fk_tdoc_edit">
            <input type="hidden" name="id_usuario_edit" id="form-id_usuario_edit">
            <label for="pk_fk_tdoc"><b>Tipo de Documento:</b></label>
            <input type="text" placeholder="Tipo de Documento" name="pk_fk_tdoc" id="form-pk_fk_tdoc" required>

            <label for="id_usuario"><b>Identificación:</b></label>
            <input type="text" placeholder="Identificación" name="id_usuario" id="form-id_usuario" required>

            <label for="nom_persona"><b>Nombre:</b></label>
            <input type="text" placeholder="Nombre" name="nom_persona" id="form-nom_persona" required>

            <label for="nom2_persona"><b>Segundo Nombre:</b></label>
            <input type="text" placeholder="Segundo Nombre" name="nom2_persona" id="form-nom2_persona">

            <label for="apell_persona"><b>Apellido:</b></label>
            <input type="text" placeholder="Apellido" name="apell_persona" id="form-apell_persona" required>

            <label for="apell2_persona"><b>Segundo Apellido:</b></label>
            <input type="text" placeholder="Segundo Apellido" name="apell2_persona" id="form-apell2_persona">

            <label for="direccion_persona"><b>Dirección:</b></label>
            <input type="text" placeholder="Dirección" name="direccion_persona" id="form-direccion_persona" required>

            <label for="telefono"><b>Teléfono:</b></label>
            <input type="text" placeholder="Teléfono" name="telefono" id="form-telefono" required>

            <label for="email"><b>Email:</b></label>
            <input type="text" placeholder="Email" name="email" id="form-email" required>

            <label for="contrasena"><b>Contraseña:</b></label>
            <input type="password" placeholder="Contraseña" name="contrasena" id="form-contrasena" required>

            <button type="submit" class="btn" name="submit">Guardar</button>
            <button type="button" class="btn cancel" onclick="closeForm()">Cancelar</button>
        </form>
    </div>

    <!-- Tabla de usuarios -->
    <div class="crud-container">
        <table>
            <tr>
                <th>Tipo de Documento</th>
                <th>Identificación</th>
                <th>Nombre</th>
                <th>Apellido</th>
                <th>Acciones</th>
            </tr>
            <?php
            $usuarios = getUsuarios($conn);
            foreach ($usuarios as $usuario) {
                echo "<tr>";
                echo "<td>" . $usuario['pk_fk_tdoc'] . "</td>";
                echo "<td>" . $usuario['id_usuario'] . "</td>";
                echo "<td>" . $usuario['nom_persona'] . "</td>";
                echo "<td>" . $usuario['nom2_persona'] . "</td>";
                echo "<td>" . $usuario['apell_persona'] . "</td>";
                echo "<td>" . $usuario['apell2_persona'] . "</td>";
                echo "<td>" . $usuario['direccion_persona'] . "</td>";
                echo "<td>" . $usuario['telefono'] . "</td>";
                echo "<td>" . $usuario['email'] . "</td>";
                echo "<td>" . $usuario['contrasena'] . "</td>";
                echo "<td><a href=\"javascript:openEditForm('" . $usuario['pk_fk_tdoc'] . "', '" . $usuario['id_usuario'] . "')\">Editar</a> | <a href=\"?action=delete&pk_fk_tdoc=" . $usuario['pk_fk_tdoc'] . "&id_usuario=" . $usuario['id_usuario'] . "\" onclick=\"return confirm('¿Estás seguro de que deseas eliminar este usuario?')\">Eliminar</a></td>";
                echo "</tr>";
            }
            ?>
        </table>
    </div>

    <script>
        // Abrir el formulario de agregar usuario
        function openForm() {
            document.getElementById("myForm").style.display = "block";
            document.getElementById("form-title").innerHTML = "Agregar Usuario";
            document.getElementById("form-action").value = "add";
            document.getElementById("form-pk_fk_tdoc_edit").value = "";
            document.getElementById("form-id_usuario_edit").value = "";
            document.getElementById("form-pk_fk_tdoc").value = "";
            document.getElementById("form-id_usuario").value = "";
            document.getElementById("form-nom_persona").value = "";
            document.getElementById("form-nom2_persona").value = "";
            document.getElementById("form-apell_persona").value = "";
            document.getElementById("form-apell2_persona").value = "";
            document.getElementById("form-direccion_persona").value = "";
            document.getElementById("form-telefono").value = "";
            document.getElementById("form-email").value = "";
            document.getElementById("form-contrasena").value = "";
        }

        // Abrir el formulario de editar usuario
        function openEditForm(pk_fk_tdoc, id_usuario) {
            document.getElementById("myForm").style.display = "block";
            document.getElementById("form-title").innerHTML = "Editar Usuario";
            document.getElementById("form-action").value = "edit";
            document.getElementById("form-pk_fk_tdoc_edit").value = pk_fk_tdoc;
            document.getElementById("form-id_usuario_edit").value = id_usuario;

            // Obtener los datos del usuario para mostrarlos en el formulario de edición
            var xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    var usuario = JSON.parse(this.responseText);
                    document.getElementById("form-pk_fk_tdoc").value = usuario.pk_fk_tdoc;
                    document.getElementById("form-id_usuario").value = usuario.id_usuario;
                    document.getElementById("form-nom_persona").value = usuario.nom_persona;
                    document.getElementById("form-nom2_persona").value = usuario.nom2_persona;
                    document.getElementById("form-apell_persona").value = usuario.apell_persona;
                    document.getElementById("form-apell2_persona").value = usuario.apell2_persona;
                    document.getElementById("form-direccion_persona").value = usuario.direccion_persona;
                    document.getElementById("form-telefono").value = usuario.telefono;
                    document.getElementById("form-email").value = usuario.email;
                    document.getElementById("form-contrasena").value = usuario.contrasena;
                }
            };
            xhttp.open("GET", "get_usuario.php?pk_fk_tdoc=" + pk_fk_tdoc + "&id_usuario=" + id_usuario, true);
            xhttp.send();
        }

        // Cerrar el formulario
        function closeForm() {
            document.getElementById("myForm").style.display = "none";
        }
    </script>
    <a href="admin.php">Volver al panel de administración</a>
</body>
</html>
