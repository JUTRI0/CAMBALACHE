<?php
session_start();

// Verificar si el usuario no ha iniciado sesión
if (!isset($_SESSION['email'])) {
    header("Location: login.php");
    exit();
}

// Obtener el email del usuario para mostrarlo en la página de administrador
$email = $_SESSION['email'];

// Configuración de la conexión a la base de datos
$host = "localhost";
$user = "root";
$password = "";
$database = "cambalaches";

// Conexión a la base de datos
$conn = new mysqli($host, $user, $password, $database);

// Verificar si hay errores en la conexión
if ($conn->connect_error) {
    die("Error en la conexión a la base de datos: " . $conn->connect_error);
}

// Función para obtener todos los registros de la tabla administrador
function obtenerAdministradores($conn) {
    $query = "SELECT * FROM administrador";
    $result = $conn->query($query);
    $administradores = [];

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $administradores[] = $row;
        }
    }

    return $administradores;
}

// Obtener la lista de administradores
$administradores = obtenerAdministradores($conn);

// Función para insertar un nuevo registro de administrador
function insertarAdministrador($conn, $tdoc, $id) {
    $query = "INSERT INTO administrador (tdoc_admin, id_admin) VALUES ('$tdoc', '$id')";
    $result = $conn->query($query);

    if ($result) {
        echo "El administrador se ha agregado correctamente.";
    } else {
        echo "Error al agregar el administrador: " . $conn->error;
    }
}

// Función para eliminar un registro de administrador
function eliminarAdministrador($conn, $tdoc, $id) {
    $query = "DELETE FROM administrador WHERE tdoc_admin='$tdoc' AND id_admin='$id'";
    $result = $conn->query($query);

    if ($result) {
        echo "El administrador se ha eliminado correctamente.";
    } else {
        echo "Error al eliminar el administrador: " . $conn->error;
    }
}

// Función para actualizar un registro de administrador
function actualizarAdministrador($conn, $tdoc, $id, $nuevoId) {
    $query = "UPDATE administrador SET id_admin='$nuevoId' WHERE tdoc_admin='$tdoc' AND id_admin='$id'";
    $result = $conn->query($query);

    if ($result) {
        echo "El administrador se ha actualizado correctamente.";
    } else {
        echo "Error al actualizar el administrador: " . $conn->error;
    }
}

// Verificar si se ha enviado el formulario de agregar administrador
if (isset($_POST['agregar'])) {
    $tdoc = $_POST['tdoc'];
    $id = $_POST['id'];

    insertarAdministrador($conn, $tdoc, $id);
}

// Verificar si se ha enviado el formulario de eliminar administrador
if (isset($_POST['eliminar'])) {
    $tdoc = $_POST['tdoc'];
    $id = $_POST['id'];

    eliminarAdministrador($conn, $tdoc, $id);
}

// Verificar si se ha enviado el formulario de actualizar administrador
if (isset($_POST['actualizar'])) {
    $tdoc = $_POST['tdoc'];
    $id = $_POST['id'];
    $nuevoId = $_POST['nuevo_id'];

    actualizarAdministrador($conn, $tdoc, $id, $nuevoId);
}

// Cerrar la conexión a la base de datos
$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Página de Administrador</title>
</head>
<body>
    <h2>Bienvenido, <?php echo $email; ?></h2>
    <p>Contenido exclusivo para usuarios administradores.</p>

    <!-- Mostrar la tabla de administradores -->
    <h3>Tabla de Administradores</h3>
    <table>
        <tr>
            <th>Tipo Documento</th>
            <th>ID</th>
            <th>Acciones</th>
        </tr>
        <?php foreach ($administradores as $administrador): ?>
            <tr>
                <td><?php echo $administrador['tdoc_admin']; ?></td>
                <td><?php echo $administrador['id_admin']; ?></td>
                <td>
                    <form method="post" style="display: inline;">
                        <input type="hidden" name="tdoc" value="<?php echo $administrador['tdoc_admin']; ?>">
                        <input type="hidden" name="id" value="<?php echo $administrador['id_admin']; ?>">
                        <button type="submit" name="eliminar">Eliminar</button>
                    </form>
                    <form method="post" style="display: inline;">
                        <input type="hidden" name="tdoc" value="<?php echo $administrador['tdoc_admin']; ?>">
                        <input type="hidden" name="id" value="<?php echo $administrador['id_admin']; ?>">
                        <input type="text" name="nuevo_id" placeholder="Nuevo ID">
                        <button type="submit" name="actualizar">Actualizar</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
    </table>

    <!-- Formulario para agregar un nuevo administrador -->
    <h3>Agregar Administrador</h3>
    <form method="post">
        <label>Tipo Documento:</label>
        <input type="text" name="tdoc" required>
        <br>
        <label>ID:</label>
        <input type="text" name="id" required>
        <br>
        <button type="submit" name="agregar">Agregar</button>
    </form>

    <a href="admin.php">Volver al panel de administración</a>
</body>
</html>
