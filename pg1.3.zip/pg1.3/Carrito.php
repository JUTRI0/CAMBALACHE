<?php
session_start();

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION['email'])) {
    header("Location: login.php");
    exit();
}

// Obtener el email del usuario
$email = $_SESSION['email'];

// Obtener los productos del carrito del usuario actual
$carrito = isset($_SESSION['carrito']) ? $_SESSION['carrito'] : array();

// Calcular el total del carrito
$total = 0;
foreach ($carrito as $producto) {
    $total += $producto['valor_prod_cant'];
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Carrito de Compras</title>
    <link rel="stylesheet" href="bootstrap.min.css">
    <style>
        .product-row {
            margin-bottom: 10px;
        }
        .total {
            font-weight: bold;
        }
    </style>
</head>
<body>
    <h2>Carrito de Compras</h2>
    <h4>Bienvenido, <?php echo $email; ?></h4>

    <div class="container">
        <table class="table">
            <thead>
                <tr>
                    <th>Código</th>
                    <th>Descripción</th>
                    <th>Cantidad</th>
                    <th>Valor</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($carrito as $producto): ?>
                    <tr>
                        <td><?php echo $producto['cod_producto']; ?></td>
                        <td><?php echo $producto['desc_producto']; ?></td>
                        <td><?php echo $producto['cantidad_prod']; ?></td>
                        <td><?php echo $producto['valor_prod_cant']; ?></td>
                        <td>
                            <form action="eliminar_producto.php" method="post">
                                <input type="hidden" name="cod_producto" value="<?php echo $producto['cod_producto']; ?>">
                                <input type="submit" class="btn btn-danger" value="Eliminar">
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
            <tfoot>
                <tr class="total">
                    <td colspan="3">Total:</td>
                    <td><?php echo $total; ?></td>
                    <td></td>
                </tr>
            </tfoot>
        </table>
    </div>

    <a href="productos.php" class="btn btn-primary">Seguir comprando</a>
    <a href="checkout.php" class="btn btn-success">Realizar compra</a>
    <a href="logout.php" class="btn btn-danger">Cerrar sesión</a>

    <script src="bootstrap.min.js"></script>
</body>
</html>
