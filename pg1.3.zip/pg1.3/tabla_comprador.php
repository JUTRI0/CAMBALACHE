<?php
// Establecer la conexión a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "cambalaches";

$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar si hay errores en la conexión
if ($conn->connect_error) {
    die("Error en la conexión: " . $conn->connect_error);
}

// Función para obtener todos los registros de la tabla de comprador
function getCompradores($conn) {
    $sql = "SELECT * FROM comprador";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        return $result->fetch_all(MYSQLI_ASSOC);
    } else {
        return [];
    }
}

// Función para agregar un nuevo registro de comprador
function agregarComprador($conn, $tdoc, $id) {
    $sql = "INSERT INTO comprador (tdoc_comprador, id_comprador) VALUES ('$tdoc', '$id')";

    if ($conn->query($sql) === TRUE) {
        echo "Registro agregado exitosamente.";
    } else {
        echo "Error al agregar el registro: " . $conn->error;
    }
}

// Función para borrar un registro de comprador
function borrarComprador($conn, $tdoc, $id) {
    $sql = "DELETE FROM comprador WHERE tdoc_comprador = '$tdoc' AND id_comprador = '$id'";

    if ($conn->query($sql) === TRUE) {
        echo "Registro eliminado exitosamente.";
    } else {
        echo "Error al eliminar el registro: " . $conn->error;
    }
}

// Función para actualizar un registro de comprador
function actualizarComprador($conn, $tdoc, $id, $nuevoTdoc, $nuevoId) {
    $sql = "UPDATE comprador SET tdoc_comprador = '$nuevoTdoc', id_comprador = '$nuevoId' WHERE tdoc_comprador = '$tdoc' AND id_comprador = '$id'";

    if ($conn->query($sql) === TRUE) {
        echo "Registro actualizado exitosamente.";
    } else {
        echo "Error al actualizar el registro: " . $conn->error;
    }
}

// Procesar las acciones de agregar, borrar o actualizar si se envía el formulario
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['agregar'])) {
        $tdoc = $_POST['tdoc'];
        $id = $_POST['id'];
        agregarComprador($conn, $tdoc, $id);
    } elseif (isset($_POST['borrar'])) {
        $tdoc = $_POST['tdoc'];
        $id = $_POST['id'];
        borrarComprador($conn, $tdoc, $id);
    } elseif (isset($_POST['actualizar'])) {
        $tdoc = $_POST['tdoc'];
        $id = $_POST['id'];
        $nuevoTdoc = $_POST['nuevo_tdoc'];
        $nuevoId = $_POST['nuevo_id'];
        actualizarComprador($conn, $tdoc, $id, $nuevoTdoc, $nuevoId);
    }
}

// Obtener los registros existentes de comprador
$compradores = getCompradores($conn);

// Cerrar la conexión a la base de datos
$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>CRUD Comprador</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }

        th, td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        form {
            margin-bottom: 16px;
        }

        input[type=text] {
            padding: 8px;
        }

        input[type=submit] {
            padding: 8px 16px;
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
        }

        .action-buttons {
            display: flex;
            align-items: center;
        }

        .action-buttons input[type=submit] {
            margin-left: 8px;
        }
    </style>
</head>
<body>
    <h2>CRUD Comprador</h2>

    <!-- Mostrar la tabla de registros -->
    <table>
        <tr>
            <th>Tipo de Documento</th>
            <th>ID</th>
            <th>Acciones</th>
        </tr>
        <?php foreach ($compradores as $comprador) : ?>
            <tr>
                <td><?php echo $comprador['tdoc_comprador']; ?></td>
                <td><?php echo $comprador['id_comprador']; ?></td>
                <td class="action-buttons">
                    <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                        <input type="hidden" name="tdoc" value="<?php echo $comprador['tdoc_comprador']; ?>">
                        <input type="hidden" name="id" value="<?php echo $comprador['id_comprador']; ?>">
                        <input type="submit" name="borrar" value="Borrar">
                    </form>
                    <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                        <input type="hidden" name="tdoc" value="<?php echo $comprador['tdoc_comprador']; ?>">
                        <input type="hidden" name="id" value="<?php echo $comprador['id_comprador']; ?>">
                        <input type="text" name="nuevo_tdoc" placeholder="Nuevo TDoc" required>
                        <input type="text" name="nuevo_id" placeholder="Nuevo ID" required>
                        <input type="submit" name="actualizar" value="Actualizar">
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
    </table>

    <!-- Formulario para agregar un registro -->
    <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <h3>Agregar Comprador</h3>
        <label for="tdoc">Tipo de Documento:</label>
        <input type="text" id="tdoc" name="tdoc" required>
        <label for="id">ID:</label>
        <input type="text" id="id" name="id" required>
        <input type="submit" name="agregar" value="Agregar">
    </form>
    <a href="admin.php">Volver al panel de administración</a>
</body>
</html>

