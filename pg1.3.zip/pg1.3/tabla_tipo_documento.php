<?php
session_start();

// Verificar si el usuario no ha iniciado sesión
if (!isset($_SESSION['email'])) {
    header("Location: login.php");
    exit();
}

// Obtener el email del usuario para mostrarlo en la página de administrador
$email = $_SESSION['email'];

// Configuración de la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "cambalaches";

// Conexión a la base de datos
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar si hay algún error en la conexión
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

// Función para obtener todos los registros de la tabla tipo_documento
function getTipoDocumentos($conn) {
    $sql = "SELECT * FROM tipo_documento";
    $result = $conn->query($sql);

    $tipoDocumentos = array();
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $tipoDocumentos[] = $row;
        }
    }

    return $tipoDocumentos;
}

// Función para agregar un nuevo tipo de documento
function addTipoDocumento($conn, $tdoc, $desc_tdoc, $estado_tdoc) {
    $sql = "INSERT INTO tipo_documento (tdoc, desc_tdoc, estado_tdoc) VALUES ('$tdoc', '$desc_tdoc', '$estado_tdoc')";

    if ($conn->query($sql) === TRUE) {
        return true;
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
        return false;
    }
}

// Función para actualizar un tipo de documento existente
function updateTipoDocumento($conn, $tdoc, $desc_tdoc, $estado_tdoc) {
    $sql = "UPDATE tipo_documento SET desc_tdoc='$desc_tdoc', estado_tdoc='$estado_tdoc' WHERE tdoc='$tdoc'";

    if ($conn->query($sql) === TRUE) {
        return true;
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
        return false;
    }
}

// Función para eliminar un tipo de documento
function deleteTipoDocumento($conn, $tdoc) {
    $sql = "DELETE FROM tipo_documento WHERE tdoc='$tdoc'";

    if ($conn->query($sql) === TRUE) {
        return true;
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
        return false;
    }
}

// Procesar el formulario de agregar o actualizar tipo de documento
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['add'])) {
        $tdoc = $_POST['tdoc'];
        $desc_tdoc = $_POST['desc_tdoc'];
        $estado_tdoc = isset($_POST['estado_tdoc']) ? 1 : 0;

        if (addTipoDocumento($conn, $tdoc, $desc_tdoc, $estado_tdoc)) {
            echo "Tipo de documento agregado exitosamente.";
        }
    } elseif (isset($_POST['update'])) {
        $tdoc = $_POST['tdoc'];
        $desc_tdoc = $_POST['desc_tdoc'];
        $estado_tdoc = isset($_POST['estado_tdoc']) ? 1 : 0;

        if (updateTipoDocumento($conn, $tdoc, $desc_tdoc, $estado_tdoc)) {
            echo "Tipo de documento actualizado exitosamente.";
        }
    }
}

// Procesar el formulario de eliminar tipo de documento
if (isset($_POST['delete'])) {
    $tdoc = $_POST['tdoc'];

    if (deleteTipoDocumento($conn, $tdoc)) {
        echo "Tipo de documento eliminado exitosamente.";
    }
}

// Obtener todos los tipo de documento de la base de datos
$tipoDocumentos = getTipoDocumentos($conn);

// Cerrar la conexión a la base de datos
$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>CRUD - Tabla tipo_documento</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }

        th, td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        tr:hover {
            background-color: #f5f5f5;
        }
    </style>
</head>
<body>
    <h2>Bienvenido, <?php echo $email; ?></h2>
    <h3>Tabla tipo_documento</h3>
    <h4>Registros:</h4>
    <table>
        <tr>
            <th>Tipo de Documento</th>
            <th>Descripción</th>
            <th>Estado</th>
            <th>Acciones</th>
        </tr>
        <?php foreach ($tipoDocumentos as $tipoDocumento) { ?>
            <tr>
                <td><?php echo $tipoDocumento['tdoc']; ?></td>
                <td><?php echo $tipoDocumento['desc_tdoc']; ?></td>
                <td><?php echo $tipoDocumento['estado_tdoc'] == 1 ? 'Activo' : 'Inactivo'; ?></td>
                <td>
                    <form method="post" style="display: inline;">
                        <input type="hidden" name="tdoc" value="<?php echo $tipoDocumento['tdoc']; ?>">
                        <input type="submit" name="delete" value="Eliminar">
                    </form>
                    <button onclick="editTipoDocumento('<?php echo $tipoDocumento['tdoc']; ?>',
                                                      '<?php echo $tipoDocumento['desc_tdoc']; ?>',
                                                      <?php echo $tipoDocumento['estado_tdoc']; ?>)">Editar</button>
                </td>
            </tr>
        <?php } ?>
    </table>

    <h4>Agregar nuevo tipo de documento:</h4>
    <form method="post">
        <label for="tdoc">Tipo de Documento:</label>
        <input type="text" id="tdoc" name="tdoc" required><br><br>
        <label for="desc_tdoc">Descripción:</label>
        <input type="text" id="desc_tdoc" name="desc_tdoc" required><br><br>
        <label for="estado_tdoc">Estado:</label>
        <input type="checkbox" id="estado_tdoc" name="estado_tdoc" value="1"><br><br>
        <input type="submit" name="add" value="Agregar">
    </form>

    <h4>Editar tipo de documento:</h4>
    <form method="post" id="editForm" style="display: none;">
        <input type="hidden" id="edit_tdoc" name="tdoc">
        <label for="edit_desc_tdoc">Descripción:</label>
        <input type="text" id="edit_desc_tdoc" name="desc_tdoc" required><br><br>
        <label for="edit_estado_tdoc">Estado:</label>
        <input type="checkbox" id="edit_estado_tdoc" name="estado_tdoc" value="1"><br><br>
        <input type="submit" name="update" value="Actualizar">
    </form>
    <a href="admin.php">Volver al panel de administración</a>

    <script>
        function editTipoDocumento(tdoc, desc_tdoc, estado_tdoc) {
            document.getElementById('edit_tdoc').value = tdoc;
            document.getElementById('edit_desc_tdoc').value = desc_tdoc;
            document.getElementById('edit_estado_tdoc').checked = estado_tdoc === 1;
            document.getElementById('editForm').style.display = 'block';
        }
    </script>
</body>
</html>
