<?php
session_start();

// Verificar si el usuario no ha iniciado sesión
if (!isset($_SESSION['email'])) {
    header("Location: login.php");
    exit();
}

// Obtener el email del usuario para mostrarlo en la página de administrador
$email = $_SESSION['email'];
?>

<!DOCTYPE html>
<html>
<head>
    <title>Página de Administrador</title>
    <!-- Agregar los enlaces CSS de Bootstrap -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
    body {
      background: #fbc2eb;
    background: -webkit-linear-gradient(to right, rgba(251, 194, 235, 1), rgba(166, 193, 238, 1));
    background: linear-gradient(to right, rgba(251, 194, 235, 1), rgba(166, 193, 238, 1));
    height: 100vh;
    }

    .container {
      background-color: rgba(255, 255, 255, 0.8);
      border-radius: 5px;
      padding: 20px;
      margin-top: 100px;
    }
  </style>
</head>
<body>
    <div class="container">
        <h2>Bienvenido, <?php echo $email; ?></h2>
        <p>Contenido exclusivo para usuarios administradores.</p>
        <ul class="list-group">
            <li class="list-group-item"><a href="tabla_tipo_documento.php">Tabla tipo_documento</a></li>
            <li class="list-group-item"><a href="tabla_roles.php">Tabla roles</a></li>
            <li class="list-group-item"><a href="tabla_comprador.php">Tabla comprador</a></li>
            <li class="list-group-item"><a href="tabla_administrador.php">Tabla administrador</a></li>
            <li class="list-group-item"><a href="tabla_vendedor.php">Tabla vendedor</a></li>
            <li class="list-group-item"><a href="tabla_tienda.php">Tabla tienda</a></li>
            <li class="list-group-item"><a href="tabla_categorias.php">Tabla categorias</a></li>
            <li class="list-group-item"><a href="tabla_factura_productos.php">Tabla factura_productos</a></li>
            <li class="list-group-item"><a href="tabla_productos.php">Tabla productos</a></li>
            <li class="list-group-item"><a href="tabla_factura.php">Tabla factura</a></li>
            <li class="list-group-item"><a href="tabla_factura_venta.php">Tabla factura_venta</a></li>
            <li class="list-group-item"><a href="tabla_usuarios.php">Tabla usuarios</a></li>
            <li class="list-group-item"><a href="tabla_usuario_has_roles.php">Tabla usuario_has_roles</a></li>
        </ul>
        <a href="logout.php" class="btn btn-primary mt-3">Cerrar sesión</a>
    </div>

    <!-- Agregar los scripts de JavaScript de Bootstrap -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
