<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Realizar la conexión a la base de datos
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "cambalaches";

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Verificar la conexión
    if ($conn->connect_error) {
        die("Error en la conexión a la base de datos: " . $conn->connect_error);
    }

    // Obtener los datos del formulario
    $correo = $_POST['correo'];
    $idUsuario = $_POST['id_usuario'];

    // Consulta SQL para verificar si el correo y el ID de usuario coinciden en la base de datos
    $sql = "SELECT * FROM usuarios WHERE email = '$correo' AND id_usuario = '$idUsuario'";
    $result = $conn->query($sql);

    // Verificar si se encontró una coincidencia
    if ($result->num_rows > 0) {
        // Redireccionar al archivo "actualizar_contrasena.php" y pasar el correo y el ID de usuario como parámetros
        header("Location: actualizar_contrasena.php?correo=$correo&id_usuario=$idUsuario");
        exit();
    } else {
        echo "Los datos ingresados no coinciden. Por favor, inténtalo nuevamente.";
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Recuperar Contraseña</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
    <h2 class="text-center">Recuperar Contraseña</h2>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <form method="POST" action="">
                    <div class="mb-3">
                        <label for="correo" class="form-label">Correo electrónico:</label>
                        <input type="email" class="form-control" id="correo" name="correo" required>
                    </div>
                    <div class="mb-3">
                        <label for="id_usuario" class="form-label">ID de usuario:</label>
                        <input type="text" class="form-control" id="id_usuario" name="id_usuario" required>
                    </div>
                    <div class="text-center">
                        <button type="submit" class="btn btn-primary">Recuperar Contraseña</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
</body>
</html>



