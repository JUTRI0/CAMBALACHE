<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Realizar la conexión a la base de datos
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "cambalaches";

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Verificar la conexión
    if ($conn->connect_error) {
        die("Error en la conexión a la base de datos: " . $conn->connect_error);
    }

    // Obtener los datos del formulario
    $correo = $_POST['correo'];
    $idUsuario = $_POST['id_usuario'];
    $nuevaContrasena= base64_encode($_POST['nueva_contrasena']);

    // Consulta SQL para actualizar la contraseña en la base de datos
    $sql = "UPDATE usuarios SET contrasena = '$nuevaContrasena' WHERE email = '$correo' AND id_usuario = '$idUsuario'";
    $result = $conn->query($sql);

    // Verificar si la actualización fue exitosa
    if ($conn->affected_rows > 0) {
        echo "La contraseña se actualizó correctamente. Ahora puedes copiar y pegar la nueva contraseña para usarla de inmediato.";
    } else {
        echo "No se pudo actualizar la contraseña. Por favor, inténtalo nuevamente.";
    }

    $conn->close();
} else {
    // Obtener el correo y el ID de usuario de los parámetros de la URL
    $correo = $_GET['correo'];
    $idUsuario = $_GET['id_usuario'];
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Actualizar Contraseña</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
    <h2 class="text-center">Actualizar Contraseña</h2>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <form method="POST" action="">
                    <input type="hidden" name="correo" value="<?php echo $correo; ?>">
                    <input type="hidden" name="id_usuario" value="<?php echo $idUsuario; ?>">
                    <div class="mb-3">
                        <label for="nueva_contrasena" class="form-label">Nueva Contraseña:</label>
                        <input type="password" class="form-control" id="nueva_contrasena" name="nueva_contrasena" required>
                    </div>
                    <div class="text-center">
                        <button type="submit" class="btn btn-primary">Actualizar Contraseña</button>
                    </div>
                </form>
                <div class="text-center mt-3">
                    <a href="../PagPrincipal.html" class="btn btn-secondary">Pagina principal</a>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
</body>
</html>


