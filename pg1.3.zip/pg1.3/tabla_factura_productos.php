<?php
// Configuración de la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "cambalaches";

// Crear la conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die("Error en la conexión: " . $conn->connect_error);
}

// Función para obtener todos los registros de la tabla factura_productos
function obtenerRegistros() {
    global $conn;
    $sql = "SELECT * FROM factura_productos";
    $result = $conn->query($sql);
    $registros = array();

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $registros[] = $row;
        }
    }

    return $registros;
}

// Función para agregar un nuevo registro a la tabla factura_productos
function agregarRegistro($n_factura, $cod_producto, $cantidad_prod, $valor_prod_cant) {
    global $conn;
    $sql = "INSERT INTO factura_productos (fk_pk_n_factura, fk_pk_cod_producto, cantidad_prod, valor_prod_cant) VALUES ('$n_factura', '$cod_producto', '$cantidad_prod', '$valor_prod_cant')";

    if ($conn->query($sql) === TRUE) {
        echo "Registro agregado correctamente.";
    } else {
        echo "Error al agregar el registro: " . $conn->error;
    }
}

// Función para borrar un registro de la tabla factura_productos
function borrarRegistro($n_factura, $cod_producto) {
    global $conn;
    $sql = "DELETE FROM factura_productos WHERE fk_pk_n_factura='$n_factura' AND fk_pk_cod_producto='$cod_producto'";

    if ($conn->query($sql) === TRUE) {
        echo "Registro eliminado correctamente.";
    } else {
        echo "Error al eliminar el registro: " . $conn->error;
    }
}

// Función para actualizar un registro de la tabla factura_productos
function actualizarRegistro($n_factura, $cod_producto, $cantidad_prod, $valor_prod_cant) {
    global $conn;
    $sql = "UPDATE factura_productos SET cantidad_prod='$cantidad_prod', valor_prod_cant='$valor_prod_cant' WHERE fk_pk_n_factura='$n_factura' AND fk_pk_cod_producto='$cod_producto'";

    if ($conn->query($sql) === TRUE) {
        echo "Registro actualizado correctamente.";
    } else {
        echo "Error al actualizar el registro: " . $conn->error;
    }
}

// Verificar si se ha enviado el formulario de agregar
if (isset($_POST['agregar'])) {
    $n_factura = $_POST['n_factura'];
    $cod_producto = $_POST['cod_producto'];
    $cantidad_prod = $_POST['cantidad_prod'];
    $valor_prod_cant = $_POST['valor_prod_cant'];

    agregarRegistro($n_factura, $cod_producto, $cantidad_prod, $valor_prod_cant);
}

// Verificar si se ha enviado el formulario de borrar
if (isset($_POST['borrar'])) {
    $n_factura = $_POST['n_factura'];
    $cod_producto = $_POST['cod_producto'];

    borrarRegistro($n_factura, $cod_producto);
}

// Verificar si se ha enviado el formulario de actualizar
if (isset($_POST['actualizar'])) {
    $n_factura = $_POST['n_factura'];
    $cod_producto = $_POST['cod_producto'];
    $cantidad_prod = $_POST['cantidad_prod'];
    $valor_prod_cant = $_POST['valor_prod_cant'];

    actualizarRegistro($n_factura, $cod_producto, $cantidad_prod, $valor_prod_cant);
}

// Obtener todos los registros de la tabla factura_productos
$registros = obtenerRegistros();
?>

<!DOCTYPE html>
<html>
<head>
    <title>CRUD de factura_productos</title>
    <style>
        table {
            border-collapse: collapse;
        }

        table, th, td {
            border: 1px solid black;
            padding: 5px;
        }
    </style>
</head>
<body>
    <h2>Tabla factura_productos</h2>

    <!-- Mostrar los registros existentes -->
    <table>
        <tr>
            <th>Número de factura</th>
            <th>Código de producto</th>
            <th>Cantidad</th>
            <th>Valor</th>
        </tr>
        <?php foreach ($registros as $registro): ?>
            <tr>
                <td><?php echo $registro['fk_pk_n_factura']; ?></td>
                <td><?php echo $registro['fk_pk_cod_producto']; ?></td>
                <td><?php echo $registro['cantidad_prod']; ?></td>
                <td><?php echo $registro['valor_prod_cant']; ?></td>
            </tr>
        <?php endforeach; ?>
    </table>

    <h3>Agregar nuevo registro</h3>
    <form method="post">
        <label>Número de factura:</label>
        <input type="text" name="n_factura" required><br><br>
        <label>Código de producto:</label>
        <input type="text" name="cod_producto" required><br><br>
        <label>Cantidad:</label>
        <input type="text" name="cantidad_prod" required><br><br>
        <label>Valor:</label>
        <input type="text" name="valor_prod_cant" required><br><br>
        <input type="submit" name="agregar" value="Agregar">
    </form>

    <h3>Borrar registro</h3>
    <form method="post">
        <label>Número de factura:</label>
        <input type="text" name="n_factura" required><br><br>
        <label>Código de producto:</label>
        <input type="text" name="cod_producto" required><br><br>
        <input type="submit" name="borrar" value="Borrar">
    </form>

    <h3>Actualizar registro</h3>
    <form method="post">
        <label>Número de factura:</label>
        <input type="text" name="n_factura" required><br><br>
        <label>Código de producto:</label>
        <input type="text" name="cod_producto" required><br><br>
        <label>Nueva cantidad:</label>
        <input type="text" name="cantidad_prod" required><br><br>
        <label>Nuevo valor:</label>
        <input type="text" name="valor_prod_cant" required><br><br>
        <input type="submit" name="actualizar" value="Actualizar">
    </form>
    <br>
    <a href="admin.php">Volver al panel de administración</a>
</body>
</html>




