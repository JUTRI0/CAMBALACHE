<?php
// Configuración de la conexión a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "cambalaches";

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

// Función para obtener todos los registros de la tabla de vendedores
function getVendedores($conn) {
    $sql = "SELECT * FROM vendedor";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        return $result->fetch_all(MYSQLI_ASSOC);
    } else {
        return array();
    }
}

// Función para insertar un nuevo vendedor en la tabla
function insertVendedor($conn, $tdoc_vendedor, $id_vendedor) {
    $sql = "INSERT INTO vendedor (tdoc_vendedor, id_vendedor) VALUES ('$tdoc_vendedor', '$id_vendedor')";
    $conn->query($sql);
}

// Función para eliminar un vendedor de la tabla
function deleteVendedor($conn, $tdoc_vendedor, $id_vendedor) {
    $sql = "DELETE FROM vendedor WHERE tdoc_vendedor = '$tdoc_vendedor' AND id_vendedor = '$id_vendedor'";
    $conn->query($sql);
}

// Función para actualizar los datos de un vendedor en la tabla
function updateVendedor($conn, $tdoc_vendedor, $id_vendedor, $new_tdoc_vendedor, $new_id_vendedor) {
    $sql = "UPDATE vendedor SET tdoc_vendedor = '$new_tdoc_vendedor', id_vendedor = '$new_id_vendedor' WHERE tdoc_vendedor = '$tdoc_vendedor' AND id_vendedor = '$id_vendedor'";
    $conn->query($sql);
}

// Procesar el formulario de agregar vendedor
if (isset($_POST['add_vendedor'])) {
    $tdoc_vendedor = $_POST['tdoc_vendedor'];
    $id_vendedor = $_POST['id_vendedor'];

    insertVendedor($conn, $tdoc_vendedor, $id_vendedor);
    header("Location: admin.php"); // Redireccionar después de agregar un vendedor
    exit();
}

// Procesar el formulario de eliminar vendedor
if (isset($_POST['delete_vendedor'])) {
    $tdoc_vendedor = $_POST['delete_tdoc_vendedor'];
    $id_vendedor = $_POST['delete_id_vendedor'];

    deleteVendedor($conn, $tdoc_vendedor, $id_vendedor);
    header("Location: admin.php"); // Redireccionar después de eliminar un vendedor
    exit();
}

// Procesar el formulario de actualizar vendedor
if (isset($_POST['update_vendedor'])) {
    $tdoc_vendedor = $_POST['tdoc_vendedor'];
    $id_vendedor = $_POST['id_vendedor'];
    $new_tdoc_vendedor = $_POST['new_tdoc_vendedor'];
    $new_id_vendedor = $_POST['new_id_vendedor'];

    updateVendedor($conn, $tdoc_vendedor, $id_vendedor, $new_tdoc_vendedor, $new_id_vendedor);
    header("Location: admin.php"); // Redireccionar después de actualizar un vendedor
    exit();
}

// Obtener todos los vendedores de la tabla
$vendedores = getVendedores($conn);

// Cerrar la conexión
$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>CRUD de Vendedores</title>
    <style>
        table {
            border-collapse: collapse;
        }

        table, th, td {
            border: 1px solid black;
            padding: 5px;
        }
    </style>
</head>
<body>
    <h2>CRUD de Vendedores</h2>

    <h3>Lista de Vendedores</h3>
    <table>
        <tr>
            <th>Tipo de Documento</th>
            <th>ID Vendedor</th>
            <th>Acciones</th>
        </tr>
        <?php foreach ($vendedores as $vendedor) { ?>
            <tr>
                <td><?php echo $vendedor['tdoc_vendedor']; ?></td>
                <td><?php echo $vendedor['id_vendedor']; ?></td>
                <td>
                    <form method="post" style="display: inline;">
                        <input type="hidden" name="delete_tdoc_vendedor" value="<?php echo $vendedor['tdoc_vendedor']; ?>">
                        <input type="hidden" name="delete_id_vendedor" value="<?php echo $vendedor['id_vendedor']; ?>">
                        <button type="submit" name="delete_vendedor">Eliminar</button>
                    </form>
                    <button onclick="openUpdateForm('<?php echo $vendedor['tdoc_vendedor']; ?>', '<?php echo $vendedor['id_vendedor']; ?>')">Actualizar</button>
                </td>
            </tr>
        <?php } ?>
    </table>

    <h3>Agregar Vendedor</h3>
    <form method="post">
        <label>Tipo de Documento:</label>
        <input type="text" name="tdoc_vendedor" required>
        <br><br>
        <label>ID Vendedor:</label>
        <input type="text" name="id_vendedor" required>
        <br><br>
        <button type="submit" name="add_vendedor">Agregar</button>
    </form>

    <h3>Actualizar Vendedor</h3>
    <div id="updateForm" style="display: none;">
        <form method="post">
            <input type="hidden" id="update_tdoc_vendedor" name="tdoc_vendedor" required>
            <input type="hidden" id="update_id_vendedor" name="id_vendedor" required>
            <label>Nuevo Tipo de Documento:</label>
            <input type="text" name="new_tdoc_vendedor" required>
            <br><br>
            <label>Nuevo ID Vendedor:</label>
            <input type="text" name="new_id_vendedor" required>
            <br><br>
            <button type="submit" name="update_vendedor">Actualizar</button>
        </form>
    </div>
    <a href="admin.php">Volver al panel de administración</a>

    <script>
        function openUpdateForm(tdoc_vendedor, id_vendedor) {
            document.getElementById('update_tdoc_vendedor').value = tdoc_vendedor;
            document.getElementById('update_id_vendedor').value = id_vendedor;
            document.getElementById('updateForm').style.display = 'block';
        }
    </script>
</body>
</html>
