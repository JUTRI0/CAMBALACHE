<?php
session_start();

if (isset($_SESSION['username'])) {
  $username = $_SESSION['username'];
  echo "<h2>Bienvenido, administrador $username</h2>";
  // Aquí puedes agregar el contenido adicional que deseas mostrar al administrador
} else {
  header('Location: login.html');
}
?>
