<?php
session_start();

// Verificar si el usuario no ha iniciado sesión
if (!isset($_SESSION['email'])) {
    header("Location: login.php");
    exit();
}

// Obtener el email del usuario para mostrarlo en la página de administrador
$email = $_SESSION['email'];

// Conexión a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "cambalaches";

// Crear la conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar si hay errores en la conexión
if ($conn->connect_error) {
    die("Error en la conexión: " . $conn->connect_error);
}

// Función para obtener todos los registros de la tabla factura
function obtenerFacturas($conn) {
    $sql = "SELECT * FROM factura";
    $result = $conn->query($sql);
    $facturas = array();

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $facturas[] = $row;
        }
    }

    return $facturas;
}

// Función para agregar una factura
function agregarFactura($conn, $n_factura, $fecha_factura, $subtotal, $iva, $total_factura) {
    $sql = "INSERT INTO factura (n_factura, fecha_factura, subtotal, iva, total_factura) VALUES ('$n_factura', '$fecha_factura', '$subtotal', '$iva', '$total_factura')";

    if ($conn->query($sql) === TRUE) {
        return true;
    } else {
        return false;
    }
}

// Función para eliminar una factura
function eliminarFactura($conn, $n_factura) {
    $sql = "DELETE FROM factura WHERE n_factura = '$n_factura'";

    if ($conn->query($sql) === TRUE) {
        return true;
    } else {
        return false;
    }
}

// Función para actualizar una factura
function actualizarFactura($conn, $n_factura, $fecha_factura, $subtotal, $iva, $total_factura) {
    $sql = "UPDATE factura SET fecha_factura = '$fecha_factura', subtotal = '$subtotal', iva = '$iva', total_factura = '$total_factura' WHERE n_factura = '$n_factura'";

    if ($conn->query($sql) === TRUE) {
        return true;
    } else {
        return false;
    }
}

// Procesar el formulario de agregar factura
if (isset($_POST['agregar_factura'])) {
    $n_factura = $_POST['n_factura'];
    $fecha_factura = $_POST['fecha_factura'];
    $subtotal = $_POST['subtotal'];
    $iva = $_POST['iva'];
    $total_factura = $_POST['total_factura'];

    if (agregarFactura($conn, $n_factura, $fecha_factura, $subtotal, $iva, $total_factura)) {
        echo "Factura agregada correctamente.";
    } else {
        echo "Error al agregar la factura: " . $conn->error;
    }
}

// Procesar el formulario de eliminar factura
if (isset($_POST['eliminar_factura'])) {
    $n_factura = $_POST['n_factura'];

    if (eliminarFactura($conn, $n_factura)) {
        echo "Factura eliminada correctamente.";
    } else {
        echo "Error al eliminar la factura: " . $conn->error;
    }
}

// Procesar el formulario de actualizar factura
if (isset($_POST['actualizar_factura'])) {
    $n_factura = $_POST['n_factura'];
    $fecha_factura = $_POST['fecha_factura'];
    $subtotal = $_POST['subtotal'];
    $iva = $_POST['iva'];
    $total_factura = $_POST['total_factura'];

    if (actualizarFactura($conn, $n_factura, $fecha_factura, $subtotal, $iva, $total_factura)) {
        echo "Factura actualizada correctamente.";
    } else {
        echo "Error al actualizar la factura: " . $conn->error;
    }
}

// Obtener todas las facturas
$facturas = obtenerFacturas($conn);
?>

<!DOCTYPE html>
<html>
<head>
    <title>CRUD de Facturas</title>
    <style>
        table {
            border-collapse: collapse;
        }

        table, th, td {
            border: 1px solid black;
            padding: 5px;
        }
    </style>
</head>
<body>
    <h2>Bienvenido, <?php echo $email; ?></h2>
    <h3>Facturas</h3>
    <table>
        <tr>
            <th>Número de Factura</th>
            <th>Fecha de Factura</th>
            <th>Subtotal</th>
            <th>IVA</th>
            <th>Total de Factura</th>
            <th>Acciones</th>
        </tr>
        <?php foreach ($facturas as $factura) { ?>
            <tr>
                <td><?php echo $factura['n_factura']; ?></td>
                <td><?php echo $factura['fecha_factura']; ?></td>
                <td><?php echo $factura['subtotal']; ?></td>
                <td><?php echo $factura['iva']; ?></td>
                <td><?php echo $factura['total_factura']; ?></td>
                <td>
                    <form method="POST" style="display: inline;">
                        <input type="hidden" name="n_factura" value="<?php echo $factura['n_factura']; ?>">
                        <input type="submit" name="eliminar_factura" value="Eliminar">
                    </form>
                    <button onclick="mostrarFormularioActualizar('<?php echo $factura['n_factura']; ?>', '<?php echo $factura['fecha_factura']; ?>', '<?php echo $factura['subtotal']; ?>', '<?php echo $factura['iva']; ?>', '<?php echo $factura['total_factura']; ?>')">Actualizar</button>
                </td>
            </tr>
        <?php } ?>
    </table>
    <br>
    <button onclick="mostrarFormularioAgregar()">Agregar Factura</button>
    <br>
    <br>
    <div id="formulario_agregar" style="display: none;">
        <h3>Agregar Factura</h3>
        <form method="POST">
            <label>Número de Factura:</label>
            <input type="text" name="n_factura" required>
            <br>
            <label>Fecha de Factura:</label>
            <input type="text" name="fecha_factura" required>
            <br>
            <label>Subtotal:</label>
            <input type="text" name="subtotal" required>
            <br>
            <label>IVA:</label>
            <input type="text" name="iva" required>
            <br>
            <label>Total de Factura:</label>
            <input type="text" name="total_factura" required>
            <br>
            <input type="submit" name="agregar_factura" value="Agregar">
            <button onclick="ocultarFormularioAgregar()">Cancelar</button>
        </form>
    </div>
    <br>
    <div id="formulario_actualizar" style="display: none;">
        <h3>Actualizar Factura</h3>
        <form method="POST">
            <input type="hidden" id="n_factura_actualizar" name="n_factura">
            <label>Fecha de Factura:</label>
            <input type="text" id="fecha_factura_actualizar" name="fecha_factura" required>
            <br>
            <label>Subtotal:</label>
            <input type="text" id="subtotal_actualizar" name="subtotal" required>
            <br>
            <label>IVA:</label>
            <input type="text" id="iva_actualizar" name="iva" required>
            <br>
            <label>Total de Factura:</label>
            <input type="text" id="total_factura_actualizar" name="total_factura" required>
            <br>
            <input type="submit" name="actualizar_factura" value="Actualizar">
            <button onclick="ocultarFormularioActualizar()">Cancelar</button>
        </form>
    </div>
    <a href="admin.php">Volver al panel de administración</a>

    <script>
        function mostrarFormularioAgregar() {
            document.getElementById('formulario_agregar').style.display = 'block';
        }

        function ocultarFormularioAgregar() {
            document.getElementById('formulario_agregar').style.display = 'none';
        }

        function mostrarFormularioActualizar(n_factura, fecha_factura, subtotal, iva, total_factura) {
            document.getElementById('n_factura_actualizar').value = n_factura;
            document.getElementById('fecha_factura_actualizar').value = fecha_factura;
            document.getElementById('subtotal_actualizar').value = subtotal;
            document.getElementById('iva_actualizar').value = iva;
            document.getElementById('total_factura_actualizar').value = total_factura;

            document.getElementById('formulario_actualizar').style.display = 'block';
        }

        function ocultarFormularioActualizar() {
            document.getElementById('formulario_actualizar').style.display = 'none';
        }
    </script>
</body>
</html>
