<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cambalaches Registro</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="Stiles/ex.css">
</head>
<body>
    <main>

        <div class="contenedor__todo">
            <div class="caja__trasera">
                <div class="caja__trasera-login">
                    <h3>¿Ya tienes una cuenta?</h3>
                    <p>Inicia sesión para entrar en la página</p>
                    <button id="btn__iniciar-sesion">Iniciar Sesión</button>
                    <button ><a href="PagPrincipal.html" >Pagina principal</a></button>
                </div>
                <div class="caja__trasera-register">
                    <h3>¿Aún no tienes una cuenta?</h3>
                    <p>Regístrate para que puedas iniciar sesión</p>
                    <button id="btn__registrarse">Regístrarse</button>
                    <button ><a href="PagPrincipal.html" >Pagina principal</a></button>

                </div>
            </div>

            <!--Formulario de Login y registro-->
            <div class="contenedor__login-register">
                <!--Login-->
                <form action="validar login.php" method='POST'  class="formulario__login">
                    <h2>Iniciar Sesión</h2>
                   <input for="email" type="email" placeholder="Correo" name="email">
               <input for="contra" type="password" placeholder="Contraseña" name="contra">
                <button>Entrar</button>
                <a href="z_admin_rc/recuperar_contrasena.php" >Recuperar contraseña</a>

                </form>

                <!--Register-->
                <form action="registro.php" method="POST" class="formulario__register">
                    <h2>Regístrarse</h2>
                    <p>
                    <input type="radio" name="docu" value="1" required> CC
                    <input type="radio" name="docu" value="2"required> TI
                    <input type="radio" name="docu" value="3"required> CE
</p>
                    <input type="text" placeholder="Numero de documento"name="ndocu" required>
                    <input type="text" placeholder="Primer nombre"name="prnom"required>
                     <input type="text" placeholder="Segundo nombre"name="snom">
                    <input type="text" placeholder="Primer apellido"name="primapel"required>
                    <input type="text" placeholder="Segundo apellido"name="sapel">
                    <input type="text" placeholder="Direccion"name="direccion"required>
                    <input type="text" placeholder="Email"name="correo"required>
                    <input type="password" placeholder="contraseña"name="contra"required>
                    <input type="text" placeholder="Telefono"name="tel"required>
                    <button>Regístrarse</button>
                </form>
            </div>
        </div>

    </main>

    <script src="imag/JS/script.js"></script>
</body>
</html>