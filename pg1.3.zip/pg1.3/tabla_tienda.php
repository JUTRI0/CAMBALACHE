<?php
session_start();

// Verificar si el usuario no ha iniciado sesión
if (!isset($_SESSION['email'])) {
    header("Location: login.php");
    exit();
}

// Obtener el email del usuario para mostrarlo en la página de administrador
$email = $_SESSION['email'];

// Configuración de la conexión a la base de datos
$host = 'localhost';
$database = 'cambalaches';
$username = 'root';
$password = '';

// Conexión a la base de datos
$conexion = mysqli_connect($host, $username, $password, $database);

// Verificar si hay un error en la conexión
if (mysqli_connect_errno()) {
    echo "Error en la conexión a la base de datos: " . mysqli_connect_error();
    exit();
}

// Función para limpiar los datos enviados por el formulario
function limpiarDatos($datos)
{
    $datos = trim($datos);
    $datos = stripslashes($datos);
    $datos = htmlspecialchars($datos);
    return $datos;
}

// Procesar la eliminación de un registro
if (isset($_GET['eliminar'])) {
    $id_tienda = limpiarDatos($_GET['eliminar']);

    // Consulta SQL para obtener la ruta de la foto antes de eliminar el registro
    $consulta_ruta = "SELECT foto FROM tienda WHERE id_tienda = '$id_tienda'";
    $resultado_ruta = mysqli_query($conexion, $consulta_ruta);
    $fila_ruta = mysqli_fetch_assoc($resultado_ruta);
    $ruta_foto = $fila_ruta['foto'];

    // Eliminar la foto correspondiente si existe
    if (!empty($ruta_foto) && file_exists($ruta_foto)) {
        unlink($ruta_foto);
    }

    // Consulta SQL para eliminar el registro de la tabla
    $consulta = "DELETE FROM tienda WHERE id_tienda = '$id_tienda'";

    if (mysqli_query($conexion, $consulta)) {
        echo "El registro ha sido eliminado correctamente.";
    } else {
        echo "Error al eliminar el registro: " . mysqli_error($conexion);
    }
}

// Procesar la actualización de un registro
if (isset($_POST['actualizar'])) {
    $id_tienda = limpiarDatos($_POST['id_tienda']);
    $nom_tienda = limpiarDatos($_POST['nom_tienda']);
    $desc_tienda = limpiarDatos($_POST['desc_tienda']);

    // Verificar si se seleccionó un nuevo archivo
    if (!empty($_FILES['foto']['name'])) {
        $nombre_archivo = $_FILES['foto']['name'];
        $tipo_archivo = $_FILES['foto']['type'];
        $tamano_archivo = $_FILES['foto']['size'];
        $temp_archivo = $_FILES['foto']['tmp_name'];

        // Directorio donde se almacenarán las fotos
        $directorio_fotos = "fotos/";

        // Ruta completa del archivo
        $ruta_foto = $directorio_fotos . $nombre_archivo;

        // Verificar el tipo de archivo
        if ($tipo_archivo == "image/jpeg" || $tipo_archivo == "image/jpg" || $tipo_archivo == "image/png") {
            // Verificar el tamaño del archivo (menor a 5MB)
            if ($tamano_archivo < 5000000) {
                // Mover el archivo al directorio de fotos
                if (move_uploaded_file($temp_archivo, $ruta_foto)) {
                    // Consulta SQL para actualizar el registro en la tabla
                    $consulta = "UPDATE tienda SET nom_tienda = '$nom_tienda', desc_tienda = '$desc_tienda', foto = '$ruta_foto' WHERE id_tienda = '$id_tienda'";

                    if (mysqli_query($conexion, $consulta)) {
                        echo "El registro ha sido actualizado correctamente.";
                    } else {
                        echo "Error al actualizar el registro: " . mysqli_error($conexion);
                    }
                } else {
                    echo "Error al subir el archivo.";
                }
            } else {
                echo "El tamaño del archivo debe ser menor a 5MB.";
            }
        } else {
            echo "Tipo de archivo no válido. Solo se permiten archivos JPEG, JPG y PNG.";
        }
    } else {
        // Consulta SQL para actualizar el registro en la tabla sin modificar la foto
        $consulta = "UPDATE tienda SET nom_tienda = '$nom_tienda', desc_tienda = '$desc_tienda' WHERE id_tienda = '$id_tienda'";

        if (mysqli_query($conexion, $consulta)) {
            echo "El registro ha sido actualizado correctamente.";
        } else {
            echo "Error al actualizar el registro: " . mysqli_error($conexion);
        }
    }
}

// Procesar la adición de un nuevo registro
if (isset($_POST['agregar'])) {
    $id_tienda = limpiarDatos($_POST['id_tienda']);
    $nom_tienda = limpiarDatos($_POST['nom_tienda']);
    $desc_tienda = limpiarDatos($_POST['desc_tienda']);

    // Verificar si se seleccionó un archivo
    if (!empty($_FILES['foto']['name'])) {
        $nombre_archivo = $_FILES['foto']['name'];
        $tipo_archivo = $_FILES['foto']['type'];
        $tamano_archivo = $_FILES['foto']['size'];
        $temp_archivo = $_FILES['foto']['tmp_name'];

        // Directorio donde se almacenarán las fotos
        $directorio_fotos = "fotos/";

        // Ruta completa del archivo
        $ruta_foto = $directorio_fotos . $nombre_archivo;

        // Verificar el tipo de archivo
        if ($tipo_archivo == "image/jpeg" || $tipo_archivo == "image/jpg" || $tipo_archivo == "image/png") {
            // Verificar el tamaño del archivo (menor a 5MB)
            if ($tamano_archivo < 5000000) {
                // Mover el archivo al directorio de fotos
                if (move_uploaded_file($temp_archivo, $ruta_foto)) {
                    // Consulta SQL para insertar el nuevo registro en la tabla
                    $consulta = "INSERT INTO tienda (id_tienda, nom_tienda, desc_tienda, foto) VALUES ('$id_tienda', '$nom_tienda', '$desc_tienda', '$ruta_foto')";

                    if (mysqli_query($conexion, $consulta)) {
                        echo "El nuevo registro ha sido agregado correctamente.";
                    } else {
                        echo "Error al agregar el nuevo registro: " . mysqli_error($conexion);
                    }
                } else {
                    echo "Error al subir el archivo.";
                }
            } else {
                echo "El tamaño del archivo debe ser menor a 5MB.";
            }
        } else {
            echo "Tipo de archivo no válido. Solo se permiten archivos JPEG, JPG y PNG.";
        }
    } else {
        echo "Debe seleccionar un archivo.";
    }
}

// Consulta SQL para obtener todos los registros de la tabla
$consulta = "SELECT * FROM tienda";
$resultado = mysqli_query($conexion, $consulta);
?>

<!DOCTYPE html>
<html>
<head>
    <title>CRUD de Tienda</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }

        th, td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        tr:hover {
            background-color: #f5f5f5;
        }

        form {
            margin-bottom: 16px;
        }
    </style>
</head>
<body>
    <h2>CRUD de Tienda</h2>
    <p>Bienvenido, <?php echo $email; ?> | <a href="logout.php">Cerrar sesión</a></p>

    <h3>Registros existentes</h3>
    <table>
        <tr>
            <th>ID</th>
            <th>Nombre</th>
            <th>Descripción</th>
            <th>Foto</th>
            <th>Acciones</th>
        </tr>
        <?php while ($fila = mysqli_fetch_assoc($resultado)): ?>
            <tr>
                <td><?php echo $fila['id_tienda']; ?></td>
                <td><?php echo $fila['nom_tienda']; ?></td>
                <td><?php echo $fila['desc_tienda']; ?></td>
                <td><img src="<?php echo $fila['foto']; ?>" width="100" height="100"></td>
                <td><?php echo $fila['fk_id_vendedor']; ?></td>
                <td><?php echo $fila['fk_pk_productos']; ?></td>
                <td>
                    <a href="editar.php?id=<?php echo $fila['id_tienda']; ?>">Editar</a>
                    <a href="index.php?eliminar=<?php echo $fila['id_tienda']; ?>">Eliminar</a>
                </td>
            </tr>
        <?php endwhile; ?>
    </table>

    <h3>Agregar nuevo registro</h3>
    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST" enctype="multipart/form-data">
        <label for="id_tienda">ID:</label>
        <input type="text" name="id_tienda" required><br>

        <label for="nom_tienda">Nombre:</label>
        <input type="text" name="nom_tienda" required><br>

        <label for="desc_tienda">Descripción:</label>
        <input type="text" name="desc_tienda" required><br>

        <label for="foto">Foto:</label>
        <input type="file" name="foto" required><br>

        <input type="submit" name="agregar" value="Agregar">
    </form>
    <a href="admin.php">Volver al panel de administración</a>
</body>
</html>

